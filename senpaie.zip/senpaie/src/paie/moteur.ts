// =====================================================================
// Moteur de calcul de paie — Sénégal
// Fonctions pures (aucun accès réseau) : testables et réutilisables.
// Tous les montants sont en FCFA, arrondis à l'unité.
// =====================================================================
import type {
  ElementPaie, Employe, EntrepriseTaux, LigneBulletin, ParametresPaie, ResultatBulletin,
} from './types';

const arrondi = (n: number) => Math.round(n);
const plafonne = (montant: number, plafond: number) => Math.max(0, Math.min(montant, plafond));

/**
 * Nombre de parts fiscales (réduction pour charges de famille).
 * Règle par défaut : 1 part + 0,5 si marié + 0,5 si conjoint sans revenu
 * + 0,5 par enfant à charge, plafonné à 5. Le gestionnaire peut forcer la
 * valeur (nb_parts_override) si la situation réelle diffère.
 */
export function calculerParts(e: Pick<Employe, 'situation_familiale' | 'conjoint_sans_revenu' | 'nombre_enfants' | 'nb_parts_override'>, partsMax = 5): number {
  if (e.nb_parts_override != null) return Math.min(Math.max(e.nb_parts_override, 1), partsMax);
  let parts = 1;
  if (e.situation_familiale === 'marie') {
    parts += 0.5;
    if (e.conjoint_sans_revenu) parts += 0.5;
  }
  parts += 0.5 * Math.max(0, e.nombre_enfants);
  return Math.min(parts, partsMax);
}

/** IR annuel brut selon le barème progressif (art. 173 CGI). */
export function irBaremeAnnuel(revenuAnnuel: number, p: ParametresPaie): number {
  let impot = 0;
  let borneBasse = 0;
  for (const t of p.ir.bareme) {
    const borneHaute = t.jusqua ?? Infinity;
    if (revenuAnnuel > borneBasse) {
      impot += (Math.min(revenuAnnuel, borneHaute) - borneBasse) * t.taux;
    }
    borneBasse = borneHaute;
    if (revenuAnnuel <= borneHaute) break;
  }
  return impot;
}

/** Réduction d'impôt pour charges de famille (art. 174 CGI). */
export function reductionFamille(irAnnuel: number, parts: number, p: ParametresPaie): number {
  // On retient la ligne de barème correspondant au nombre de parts (arrondi à 0,5 inférieur)
  const lignes = [...p.ir.reductions].sort((a, b) => a.parts - b.parts);
  const ligne = [...lignes].reverse().find((l) => l.parts <= parts) ?? lignes[0];
  if (!ligne || ligne.taux === 0) return 0;
  const brute = irAnnuel * ligne.taux;
  const encadree = Math.min(Math.max(brute, ligne.min), ligne.max);
  return Math.min(encadree, irAnnuel); // la réduction ne peut pas dépasser l'impôt
}

/** TRIMF annuelle selon le revenu brut annuel. */
export function trimfAnnuelle(revenuBrutAnnuel: number, p: ParametresPaie): number {
  for (const t of p.trimf) {
    if (t.jusqua === null || revenuBrutAnnuel <= t.jusqua) return t.montant_annuel;
  }
  return p.trimf[p.trimf.length - 1]?.montant_annuel ?? 0;
}

/**
 * Calcule un bulletin complet pour un employé sur un mois.
 * @param elements éléments fixes + variables du mois (primes, absences, avances…)
 */
export function calculerBulletin(
  employe: Employe,
  elements: ElementPaie[],
  entreprise: EntrepriseTaux,
  p: ParametresPaie,
): ResultatBulletin {
  const lignes: LigneBulletin[] = [];
  const alertes: string[] = [];

  if (employe.salaire_base < 0) throw new Error('Salaire de base négatif');

  // 1) Gains ------------------------------------------------------------
  let brut = 0, brutCotisable = 0, brutImposable = 0, autresRetenues = 0;

  const ajouterGain = (code: string, libelle: string, montant: number, cotisable: boolean, imposable: boolean) => {
    brut += montant;
    if (cotisable) brutCotisable += montant;
    if (imposable) brutImposable += montant;
    lignes.push({ code, libelle, gain: arrondi(montant) });
  };

  ajouterGain('SAL_BASE', 'Salaire de base', employe.salaire_base, true, true);
  if (employe.sursalaire > 0) ajouterGain('SURSAL', 'Sursalaire', employe.sursalaire, true, true);

  for (const { rubrique: r, montant } of elements) {
    if (!Number.isFinite(montant) || montant < 0) {
      throw new Error(`Montant invalide pour la rubrique ${r.libelle}`);
    }
    if (montant === 0) continue;

    if (r.type === 'gain') {
      // Part exonérée jusqu'au plafond, le surplus redevient cotisable et imposable
      if (r.plafond_exoneration != null && (!r.soumis_cotisations || !r.soumis_impot)) {
        const exonere = Math.min(montant, r.plafond_exoneration);
        const surplus = montant - exonere;
        brut += montant;
        brutCotisable += (r.soumis_cotisations ? montant : surplus);
        brutImposable += (r.soumis_impot ? montant : surplus);
        lignes.push({ code: r.code, libelle: r.libelle, gain: arrondi(montant) });
        if (surplus > 0) alertes.push(`${r.libelle} : ${arrondi(surplus)} FCFA au-delà du plafond d'exonération réintégrés.`);
      } else {
        ajouterGain(r.code, r.libelle, montant, r.soumis_cotisations, r.soumis_impot);
      }
    } else if (r.type === 'deduction_brut') {
      brut -= montant;
      if (r.soumis_cotisations) brutCotisable -= montant;
      if (r.soumis_impot) brutImposable -= montant;
      lignes.push({ code: r.code, libelle: r.libelle, retenue: arrondi(montant) });
    } else {
      autresRetenues += montant;
    }
  }

  brut = Math.max(0, arrondi(brut));
  brutCotisable = Math.max(0, arrondi(brutCotisable));
  brutImposable = Math.max(0, arrondi(brutImposable));

  // 2) Cotisations sociales ---------------------------------------------
  const baseRG = plafonne(brutCotisable, p.ipres_rg.plafond);
  const ipresRgSal = arrondi(baseRG * p.ipres_rg.taux_sal);
  const ipresRgPat = arrondi(baseRG * p.ipres_rg.taux_pat);
  lignes.push({ code: 'IPRES_RG', libelle: 'IPRES Régime général', base: baseRG, taux: p.ipres_rg.taux_sal, retenue: ipresRgSal, patronal: ipresRgPat });

  let baseRCC = 0, ipresRccSal = 0, ipresRccPat = 0;
  if (employe.est_cadre) {
    baseRCC = plafonne(brutCotisable, p.ipres_rcc.plafond);
    ipresRccSal = arrondi(baseRCC * p.ipres_rcc.taux_sal);
    ipresRccPat = arrondi(baseRCC * p.ipres_rcc.taux_pat);
    lignes.push({ code: 'IPRES_RCC', libelle: 'IPRES Régime cadres', base: baseRCC, taux: p.ipres_rcc.taux_sal, retenue: ipresRccSal, patronal: ipresRccPat });
  }

  const baseCSS = plafonne(brutCotisable, p.css_pf.plafond);
  const cssPf = arrondi(baseCSS * p.css_pf.taux_pat);
  const baseAT = plafonne(brutCotisable, p.css_at.plafond);
  const cssAt = arrondi(baseAT * entreprise.taux_at);
  lignes.push({ code: 'CSS_PF', libelle: 'CSS Prestations familiales', base: baseCSS, taux: p.css_pf.taux_pat, patronal: cssPf });
  lignes.push({ code: 'CSS_AT', libelle: 'CSS Accidents du travail', base: baseAT, taux: entreprise.taux_at, patronal: cssAt });

  let ipmSal = 0, ipmPat = 0;
  if (entreprise.taux_ipm_salarie > 0 || entreprise.taux_ipm_employeur > 0) {
    const baseIpm = entreprise.plafond_ipm ? plafonne(brutCotisable, entreprise.plafond_ipm) : brutCotisable;
    ipmSal = arrondi(baseIpm * entreprise.taux_ipm_salarie);
    ipmPat = arrondi(baseIpm * entreprise.taux_ipm_employeur);
    lignes.push({ code: 'IPM', libelle: 'IPM (maladie)', base: baseIpm, taux: entreprise.taux_ipm_salarie, retenue: ipmSal, patronal: ipmPat });
  }

  // 3) Impôts : IR + TRIMF (salarié), CFCE (employeur) -------------------
  const nbParts = calculerParts(employe, p.ir.parts_max);
  const cotisRetraiteSal = ipresRgSal + ipresRccSal;
  const imposableApresRetraiteAnnuel = Math.max(0, (brutImposable - cotisRetraiteSal) * 12);
  const abattement = Math.min(imposableApresRetraiteAnnuel * p.ir.abattement_taux, p.ir.abattement_plafond_annuel);
  const netImposableAnnuel = Math.max(0, Math.floor((imposableApresRetraiteAnnuel - abattement) / 1000) * 1000);
  const irBrutAnnuel = irBaremeAnnuel(netImposableAnnuel, p);
  const reduction = reductionFamille(irBrutAnnuel, nbParts, p);
  const ir = arrondi(Math.max(0, irBrutAnnuel - reduction) / 12);
  lignes.push({ code: 'IR', libelle: `Impôt sur le revenu (${nbParts} part${nbParts > 1 ? 's' : ''})`, base: arrondi(netImposableAnnuel / 12), retenue: ir });

  const trimf = arrondi((trimfAnnuelle(brutImposable * 12, p) * Math.max(1, employe.parts_trimf)) / 12);
  lignes.push({ code: 'TRIMF', libelle: 'TRIMF', base: brutImposable, retenue: trimf });

  const cfce = arrondi(brutImposable * p.cfce.taux);
  lignes.push({ code: 'CFCE', libelle: 'CFCE (contribution forfaitaire employeur)', base: brutImposable, taux: p.cfce.taux, patronal: cfce });

  // 4) Retenues diverses après net ---------------------------------------
  for (const { rubrique: r, montant } of elements) {
    if (r.type === 'retenue' && montant > 0) {
      lignes.push({ code: r.code, libelle: r.libelle, retenue: arrondi(montant) });
    }
  }
  autresRetenues = arrondi(autresRetenues);

  // 5) Totaux ------------------------------------------------------------
  const totalRetenuesSal = ipresRgSal + ipresRccSal + ipmSal + ir + trimf + autresRetenues;
  const net = brut - totalRetenuesSal;
  if (net < 0) alertes.push('Le net à payer est négatif : vérifiez les avances et retenues.');
  const coutEmployeur = brut + ipresRgPat + ipresRccPat + cssPf + cssAt + ipmPat + cfce;

  return {
    brut,
    brut_cotisable: brutCotisable,
    brut_imposable: brutImposable,
    ipres_rg_sal: ipresRgSal,
    ipres_rg_pat: ipresRgPat,
    ipres_rcc_sal: ipresRccSal,
    ipres_rcc_pat: ipresRccPat,
    css_pf: cssPf,
    css_at: cssAt,
    ipm_sal: ipmSal,
    ipm_pat: ipmPat,
    ir,
    trimf,
    cfce,
    autres_retenues: autresRetenues,
    net_a_payer: net,
    cout_employeur: coutEmployeur,
    nb_parts: nbParts,
    detail: {
      lignes,
      bases: {
        ipres_rg: baseRG,
        ipres_rcc: baseRCC,
        css: baseCSS,
        net_imposable_annuel: netImposableAnnuel,
        ir_brut_annuel: arrondi(irBrutAnnuel),
        reduction_famille_annuelle: arrondi(reduction),
      },
      alertes,
    },
  };
}
